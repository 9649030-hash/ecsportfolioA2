// Tye Oswald | 25 Mar 2026 | Timer
import processing.sound.*;
SoundFile alarm, Clicked, ClickedTwo, yahoo, iphone, stopV, whoosh, warp, grandma;
Button btnStart, btnStop, btnReset, btnMode, btnAddTime;
int totalTime, startTime, timeLeft;
boolean running;

void setup() {
  size(500, 500);
  Clicked = new SoundFile(this, "Clicked.mp3");
  ClickedTwo = new SoundFile(this, "ClickedTwo.mp3");
  yahoo = new SoundFile(this, "yahoo.mp3");
  iphone = new SoundFile(this, "iphone_alarm.mp3");
  stopV = new SoundFile(this, "StopVoice.mp3");
  whoosh =  new SoundFile(this, "whoosh.mp3");
  warp = new SoundFile(this, "warp.mp3");
  grandma = new SoundFile(this, "grandma.mp3");
  alarm = new SoundFile(this, "nuclear_warning_full.mp3");
  btnStart = new Button(100, 50, 100, 30, "Start", color(37, 255, 18), color(255));
  btnStop = new Button(400, 50, 100, 30, "Stop", color(255, 2, 2), color(255));
  btnReset = new Button(250, 450, 30, 30, "Don't", color(0, 255, 240), color(255));
  btnMode = new Button(100, 450, 50, 30, "Mode", color(178, 0, 255), color(255));
  btnAddTime = new Button(450, 450, 50, 30, "Grandma", color(124, 53, 6), color(255));
  totalTime = 10;
  startTime = 0;
  running = false;
}

void draw() {
  textSize(13);
  background(67);

  if (running == true) {
    int elapsed = (millis()- startTime)/1000;
    timeLeft = totalTime - elapsed;


    if (timeLeft <= 0) {
      timeLeft = 0;
      running = false;
      alarm.play();
      iphone.play();
    }
  }
  btnStart.display();
  btnStop.display();
  btnReset.display();
  btnMode.display();
  btnAddTime.display();
  rect(width/2, 270, 400, 200, 400);
  textSize(100);
  textAlign(CENTER, CENTER);
  fill(18, 249, 255);
  text(timeLeft, width/2, height/2);
}

void mousePressed() {
  if(btnStart.isMouseOver() == true) {
    running = true;
    startTime = millis();
       Clicked.play();
  }
  
  if(btnStop.isMouseOver() == true) {
    running = false;
    stopV.play();
  }
    if(btnAddTime.isMouseOver() == true) {
    //ClickedTwo.play();
    //yahoo.play();
    grandma.play();
  }
    if(btnReset.isMouseOver() == true) {
      running = false;
      timeLeft = 10;
   whoosh.play();
  }
    if(btnMode.isMouseOver() == true) {
   warp.play();
  }
}
