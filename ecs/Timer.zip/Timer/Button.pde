class Button {
  // Member Variables
  int x, y, w, h;
  String label;
  color c1, c2;

  // Constructor
  Button(int x, int y, int w, int h, String label, color c1, color c2) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.label = label;
   this.c1 =c1;
   this.c2 = c2;
  }

  void display() {
    if(isMouseOver()) {
      fill(c1);
    } else {
      fill(c2);
    }
    rectMode(CENTER);
    rect(x,y,w,h);
    fill(0);
    textAlign(CENTER,CENTER);
    text(label,x,y);
  }

  //boolean returns a tru or a false, while void just carries out what is in the () or {}
  boolean isMouseOver() {
    return mouseX > x-w/2 && mouseX < x+w/2 && mouseY > y-h/2 && mouseY < y+h/2;
  }

  boolean wasClicked() {
    return true;
  }
}
