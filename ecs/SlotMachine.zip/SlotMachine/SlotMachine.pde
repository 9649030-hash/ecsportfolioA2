// Tye Oswald | 18 Mar 2026 | Mini Project for Portfolio

int x, y, reel1, reel2, reel3; //Global Variable
PImage SlotHighFive, SlotWinningTwo, BlankSlots, SlotWinningThree;
boolean spinning = false;


void setup() {
  background (0, 0, 0);
  size(800,800);
  x = width/2;
  y = height/2;
  SlotHighFive = loadImage("SlotWinning.png");
  SlotWinningTwo = loadImage("SlotWinningTwo.png");
  SlotWinningThree = loadImage("SlotWinningThree.jpeg");
  BlankSlots = loadImage("BlankSlots.png");
  BlankSlots.resize(600,500);
  spinReels();
}

void draw() {
  image(SlotHighFive,0,0);
  image(SlotWinningTwo, 500, 0);
  image(BlankSlots, 150, 150);
  image(SlotWinningThree, 50,600);
  fill(255,0,0);
  textSize(120);
   if (!spinning && reel1 == reel2 && reel2 == reel3) {
    fill(0, 255, 0);
    text("JACKPOT!", 200, height - 00);
  }
  text(reel1, width/4, height/2);
  text(reel2, width/2, height/2);
  text(reel3, 3*width/4, height/2);
}


void keyPressed () {
 if (key == ' ') {
    spinning = true;
    spinReels();
    spinning = false;
  }
}

void spinReels() {
  reel1 = int(random(1, 10));
  reel2 = int(random(1, 10));
  reel3 = int(random(1, 10));
}
