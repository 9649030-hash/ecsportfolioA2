// Tye Oswald | 16 Mar 2026 | EtchASketch
// Global Variable
int x, y; // Global Variable
PImage el;

void setup() {
background (255,255,255);
  size(1001,818);
  x = width/2;
  y = height/2;
  line(x,y,x+5,y);
  el = loadImage("Etch.png");
}

void draw() {
  image(el,0,0);
  strokeWeight(6);
  stroke(0);
 // point(x,y);
  //line(x,y,x+50,y);
  //moveRight(50);
  //moveDown(50);
  //moveLeft(50);
  //moveUp(50);
  //noLoop();
}

void keyPressed () {
  if(key == 'w' || key == 'W') {
    moveUp(10);
  } else if(key == 'a' || key == 'A') {
    moveLeft(10);
  } else if(key == 's' || key == 'S') {
    moveDown(10);
  } else if(key == 'd' || key == 'D') {
    moveRight(10);
  }
  
  if(key == CODED) {
  if(keyCode == UP) {
    moveUp(20);
  } else if(keyCode == LEFT) {
    moveLeft(20); 
  }
  }
}

void moveRight(int l) {
  line(x,y,x+l,y);
    x+=l;
}

void moveDown(int l) {
  line(x,y,x,y+l);
  y = y + l;
}

void moveUp (int l) {
  line(x,y,x,y-l);
  y = y - l;
}

void moveLeft (int l) {
  line(x,y,x-l,y);
  x = x - l;
}


void mouseReleased() {
   saveFrame("line-######.png");
}
