//Tye Oswald | 23 Feb 2026 | Timeline
void setup() {
  size(950,400);
}
void draw() {
  background(#88B8FA);
  drawRef();
  histEvent(67,200,"Mar. 1918",true,"Harold Seeholzer, the founder of Beaver Mountain, buys his first pair of skis.");
  histEvent(300,300,"Dec. 1939",false,"Logan Canyon is open year-round and the Ski Club decides to install a ski tow. ");
  histEvent(450,200,"Dec. 1949",true,"A warming lodge was added. ");
  histEvent(500,300,"Apr. 1950",false," A 2,700 foot T-bar is ordered.");
  histEvent(600,200,"Dec. 1961",true," Harold and Luella call their young family together and \n form a corporation. They use horses to carry some of the supplies.");
  histEvent(630,300,"Jan. 1963",false,"The family begins construction on Little Beaver double chair, the first beginning ski lift.");
  histEvent(740,200,"Jan. 1970",true,"Harry’s Dream, a 4,600-foot double lift with 137 chairs opens. ");
  histEvent(820,300,"May, 1986",false,"Beaver Mountain finally gets electricity after running off a generator for 47 years.");
}
void drawRef() {
  textAlign(CENTER);
  textSize(36);
  fill(0);
  text("Beaver Mountain Ski Resort",width/2,70);
  textSize(20);
  text("By Tye Oswald",width/2,90);
  strokeWeight(5);
  line(50,250,900,250);
  text("1918",50,280);
  text("2000",900,280);
  strokeWeight(3);
  line(50,240,50,260);
  line(900,240,900,260);
}
void histEvent(int x, int y,String title, boolean top, String detail) {
  if(top == true){
  line(x,y,x-15,y+50);
  }else {
  line(x,y,x-15,y-50);
  }
  rectMode(CENTER);
  fill(#FA9F46);
  strokeWeight(2);
  rect(x,y,100,30,10);
  fill(0);
  text(title,x,y+5);
  if(mouseX > x-50 && mouseX < x+50 && mouseY > y-15 && mouseY < y+15) {
    text(detail,width/2,350);
  }
}
