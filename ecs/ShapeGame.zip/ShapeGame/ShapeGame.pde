// Tye Oswald | 4 Mar 2026 | ShapeGame
int x, y, tx, ty, score, x2, y2;
float tw;
PImage criminal, cop;

void setup() {
  size(1000, 1000);
  x = width/2;
  y = height/2;
  tx = int(random(30, width-30));
  ty = int(random(30, height-30));
  tw = 200;
  score = 0;
  criminal = loadImage("RedCar.png");
  cop = loadImage("CopCar.png");
}

void draw() {
  background(#00AAFC);
  scorePanel(); //calls the score
  target();
  imageMode(CENTER);
  image(criminal, x, y);
  //ellipse(x, y, 20, 20);
}
void target () {
  float d = dist(x, y, tx, ty);
  println(d);
  rectMode(CENTER); //makes the target's hitbox center
  image(cop,tx, ty);
  tw = tw -0.1;
  cop.resize(int(tw), int(tw));
  // rect(tx, ty, 50, 50);
  if (d<20) { //hitbox of target
  
   



    score = score + 1; //when cop catches crim, adds 1 point to score
    //  tx = int(random(30,width-30));
    ty = int(random(30, height-30));
  }
   if (tw<10) {
      gameOver();
    }
}

void scorePanel() {
  rectMode(CENTER);
  fill(127, 127);
  rect(width/2, 15, width, 30);
  fill(0);
  textSize(30);
  text("Cop:" + score, 20, 25);
}

void gameOver() {
  background(0);
  fill(255, 0, 0);
  textSize(40);
  text("Game Over!", width/2, height/2);
  noLoop();
}








void keyPressed() { //This "turns on the keyboard"
  if (x > width) {
    x2 = 0;
  }

  if (x < 0) {
    x2 = width;
  }
  if (x > height) {
    y2 = 0;
  }
  if (y < 0) {
    y2 = height;
  }




  // WASD and Arrow Movement
  if (key == 'w' ||key == 'W') {
    y = y - 10;
  } else if (key == 's'  || key == 'S') {
    y = y + 10;
  } else if (key == 'a' || key == 'A') {
    x = x -10;
  } else if (key == 'd' || key == 'D') {
    x = x +10;
  }
  if(keyCode == UP) {
    ty = ty - 20;
  } else if (keyCode == DOWN) {
    ty = ty +20;
  }  else if (keyCode == LEFT) {
    tx = tx -20;
  }
   else if (keyCode == RIGHT) {
    tx = tx +20;
  }
}
